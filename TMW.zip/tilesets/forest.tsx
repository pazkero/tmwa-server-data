<?xml version="1.0" encoding="UTF-8"?>
<tileset name="forest" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/forest.png" width="608" height="672"/>
</tileset>
