<?xml version="1.0" encoding="UTF-8"?>
<tileset name="woodland_water" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/woodland_water.png" width="512" height="96"/>
</tileset>
