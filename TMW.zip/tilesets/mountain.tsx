<?xml version="1.0" encoding="UTF-8"?>
<tileset name="mountain" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/mountain.png" width="416" height="448"/>
</tileset>
