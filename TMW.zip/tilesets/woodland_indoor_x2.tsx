<?xml version="1.0" encoding="UTF-8"?>
<tileset name="woodland_indoor_x2" tilewidth="32" tileheight="64">
 <image source="../graphics/tiles/woodland_indoor_x2.png" width="512" height="192"/>
</tileset>
