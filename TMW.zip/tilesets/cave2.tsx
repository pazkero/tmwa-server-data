<?xml version="1.0" encoding="UTF-8"?>
<tileset name="cave2" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/cave2.png" width="512" height="512"/>
</tileset>
