<?xml version="1.0" encoding="UTF-8"?>
<tileset name="cave2_sewer_mine_x3" tilewidth="32" tileheight="96">
 <image source="../graphics/tiles/cave2_sewer_mine_x3.png" width="256" height="96"/>
</tileset>
